PAKET SOAL - UNTITLED FORM
==========================

INFORMASI PAKET:
- Judul: Untitled Form
- Deskripsi: Tidak ada deskripsi
- Mata Kuliah: Algoritma dan Pemrograman
- Pembuat: Husnul Hakim
- Jumlah Soal: 2 set soal
- Tanggal Dibuat: 27/10/2025, 17.41.39

STRUKTUR FOLDER:
Setiap set soal memiliki struktur folder:
- 01_Soal/ : File soal utama
- 02_Kunci_Jawaban/ : File kunci jawaban
- 03_Test_Cases/ : File test cases
- README.txt : Informasi detail soal

INFORMASI DOWNLOAD:
- Total File Diunduh: 6 file
- Tanggal Download: 24/11/2025, 21.38.14
- User: Husnul Hakim

---
Diunduh dari Bank Soal Informatika
Universitas Katolik Parahyangan
© 2025