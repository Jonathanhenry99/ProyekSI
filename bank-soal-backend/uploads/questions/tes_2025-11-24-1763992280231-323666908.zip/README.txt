PAKET SOAL - BANK SOAL INFORMATIKA
==================================

INFORMASI UMUM:
- Judul: tes
- Mata Kuliah: Algoritma dan Struktur Data
- Tingkat Kesulitan: Mudah
- Dosen: Husnul Hakim
- Tahun: 2025
- Tanggal Unduh: 24/11/2025, 20.01.52

STRUKTUR FOLDER:
- 01_Soal/ : Berisi file soal utama (1 file)
- 02_Kunci_Jawaban/ : Berisi file kunci jawaban (2 file)
- 03_Test_Cases/ : Berisi file test cases (1 file)

DETAIL TAMBAHAN:
- Topik: Tidak ada topik yang ditentukan
- Deskripsi: tes
- Total File: 4 file

INFORMASI DOWNLOAD:
- ID Question Set: 21
- Waktu Download: 2025-11-24T13:01:52.866Z
- User: Husnul Hakim

CATATAN:
Jika ada folder yang kosong, berarti file untuk kategori tersebut
tidak tersedia atau gagal diunduh dari server.

---
Diunduh dari Bank Soal Informatika
Universitas Katolik Parahyangan
© 2025